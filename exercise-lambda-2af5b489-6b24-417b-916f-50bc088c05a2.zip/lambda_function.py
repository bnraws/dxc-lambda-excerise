import json
import boto3
import os
import pathlib
import logging
LOGGER = logging.getLogger()
LOGGER.setLevel(logging.INFO)
def lambda_handler(event, context):
   try:
    LOGGER.info('Event structure: %s', event)
    LOGGER.info('Our Lambda function')
    #Retrieve from the SSM Parameter Store the key/value pair
    client = boto3.client('ssm')
    response=client.get_parameters(Names=['UserName']),
    print ('SSM Parameters:', response)
    #Get the S3bucket details
    s3 = boto3.client("s3")
    bucket_name = "dxc-lambda-exercise-s3"
    #Write data into File
    s3.put_object(Bucket ="dxc-lambda-exercise-s3", Key = "dxc-log.txt", Body= str(response))
   except Exception as e:
    LOGGER.error(e)
    traceback.print_exc()
   finally:
    str(response)
    return {
     'stausCode':200,
     'body':json.dumps(str(response))
    }
   
